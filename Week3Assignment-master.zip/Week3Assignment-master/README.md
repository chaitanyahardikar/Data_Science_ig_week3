# Week3Assignment

To run the assignment, clone the repository into your system, then run  the following commands on your terminal/command prompt window:

-> cd Week3Assignment                                                                                                         
-> pip install -r requirements.txt                                                                                             
-> jupyter notebook


This should open up the jupyter notebook window on your browser, then select the .ipynb file and start coding!
